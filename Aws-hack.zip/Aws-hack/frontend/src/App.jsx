import { useState, useEffect } from "react";
import { io } from "socket.io-client";
import "./App.css";

const defaultData = {
  timestamp: "",
  predicted_usage: 0,
  expected_avg: 0,
  anomaly: false,
  advice: "",
  history: [],
};

function App() {
  const [data, setData] = useState(defaultData);
  const [error, setError] = useState("");

  useEffect(() => {
    const s = io("http://localhost:5000", {
      transports: ["websocket"],
      reconnectionAttempts: 10,
      reconnectionDelay: 2000,
    });

    s.on("connect", () => setError(""));
    s.on("disconnect", () => setError("Disconnected from backend"));
    s.on("connect_error", (err) => setError("Connection failed: " + err.message));
    s.on("energy_update", (update) => {
      setData((prev) => ({
        ...prev,
        ...update,
        history: [
          ...(prev.history || []).slice(-9),
          {
            time: update.timestamp.split(" ")[1]?.slice(0, 5) || "",
            usage: update.predicted_usage,
          },
        ],
      }));
    });

    return () => s.disconnect();
  }, []);

  const difference =
    data.expected_avg && data.predicted_usage
      ? Math.round(
          ((data.predicted_usage - data.expected_avg) / data.expected_avg) * 100
        )
      : null;

  return (
    <div className="energy-dashboard">
      {/* Sidebar */}
      <aside className="energy-sidebar">
        <div className="energy-appname">
          EnergySense Live ⚡
          <div style={{ fontSize: "12px", color: "#999" }}>
            Last updated: {data.timestamp || "—"}
          </div>
        </div>

        <div className="energy-card energy-card-advice">
          <div className="energy-card-title">What to do</div>
          <div className="energy-advice">
            <span className="energy-advice-icon" role="img" aria-label="bulb">
              
            </span>
            {data.advice || "No advice yet."}
          </div>
        </div>

        <div
          className={
            "energy-card energy-card-stats " +
            (data.anomaly ? "energy-card-anomaly" : "energy-card-normal")
          }
        >
          <div className="energy-card-title">Stats</div>
          <div className="energy-stats-row">
            <span>Predicted Usage:</span>
            <span>{data.predicted_usage} Wh</span>
          </div>
          <div className="energy-stats-row">
            <span>Expected Avg:</span>
            <span>{data.expected_avg} Wh</span>
          </div>
          <div className="energy-stats-row">
            <span>Difference:</span>
            <span
              className={data.anomaly ? "energy-diff-red" : "energy-diff-green"}
            >
              {difference !== null ? difference + "%" : "-"}
            </span>
          </div>
          <div className={data.anomaly ? "energy-anomaly" : "energy-normal"}>
            {data.anomaly ? "Anomaly detected" : "Normal usage"}
          </div>
        </div>
      </aside>

      {/* Main/chart area */}
      <main className="energy-main">
        <div className="energy-main-header">
          <span className="energy-main-title">Energy Consumption (Live)</span>
        </div>
        {data.anomaly && (
          <div className="energy-alert">
             Anomaly detected at {data.timestamp}!
          </div>
        )}
        <div className="energy-card energy-card-chart">
          {error ? (
            <div className="energy-error">{error}</div>
          ) : data.history && data.history.length ? (
            <LineChart history={data.history} />
          ) : (
            <div className="energy-nodata">Waiting for live data...</div>
          )}
        </div>
      </main>
    </div>
  );
}

function LineChart({ history }) {
  if (!history?.length) return null;
  const width = 480, height = 220, padding = 40;
  const usages = history.map((p) => p.usage);
  const times = history.map((p) => p.time);
  const minY = Math.min(...usages) * 0.95;
  const maxY = Math.max(...usages) * 1.05;
  const stepX = (width - 2 * padding) / (usages.length - 1 || 1);
  const pts = usages
    .map(
      (v, i) =>
        `${padding + i * stepX},${height - padding - ((v - minY) / (maxY - minY)) * (height - 2 * padding)}`
    )
    .join(" ");
  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="energy-svg">
      <line x1={padding} y1={height - padding} x2={width - padding} y2={height - padding} stroke="#aaa" />
      <line x1={padding} y1={padding} x2={padding} y2={height - padding} stroke="#aaa" />
      <polyline fill="none" stroke="#4287f5" strokeWidth="3" points={pts} />
      {usages.map((v, i) => (
        <circle
          key={i}
          cx={padding + i * stepX}
          cy={height - padding - ((v - minY) / (maxY - minY)) * (height - 2 * padding)}
          r="5"
          fill="#90cdf4"
          stroke="#4287f5"
          strokeWidth="2"
        />
      ))}
      {times.map((label, i) => (
        <text
          key={i}
          x={padding + i * stepX}
          y={height - padding + 22}
          fontSize="14"
          fill="#bbb"
          textAnchor="middle"
        >
          {label}
        </text>
      ))}
      <text
        x={18}
        y={height / 2}
        fontSize="14"
        fill="#bbb"
        textAnchor="middle"
        alignmentBaseline="middle"
        transform={`rotate(-90, 18, ${height / 2})`}
      >
        Usage (Wh)
      </text>
    </svg>
  );
}

export default App;

