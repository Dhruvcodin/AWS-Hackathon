from flask import Flask, jsonify
from flask_socketio import SocketIO
from handler import detect_anomaly
import threading, time

app = Flask(__name__)

socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

@app.route("/")
def home():
    return jsonify({"status": "Flask backend running"})

def background_stream():
    while True:
        data = detect_anomaly()
        socketio.emit("energy_update", data)  # <-- broadcast argument removed
        print(
            f"[{data['timestamp']}]  Predicted: {data['predicted_usage']} Wh | "
            f"Actual: {data['expected_avg']} Wh | "
            f"{' Anomaly' if data['anomaly'] else ' Normal'}"
        )
        time.sleep(5)

@socketio.on("connect")
def connected():
    print(" Client connected")

@socketio.on("disconnect")
def disconnected():
    print(" Client disconnected")

if __name__ == "__main__":
    threading.Thread(target=background_stream, daemon=True).start()
    socketio.run(app, host="0.0.0.0", port=5000)
