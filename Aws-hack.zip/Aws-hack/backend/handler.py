import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from ai_model import generate_advice
import random
import warnings

# Load dataset
df = pd.read_csv("energydata_complete.csv", parse_dates=["date"])
df = df.drop(columns=["rv1", "rv2"])

# Feature and target columns
feature_cols = [
    'T1','RH_1','T2','RH_2','T3','RH_3','T4','RH_4','T5','RH_5',
    'T6','RH_6','T7','RH_7','T8','RH_8','T9','RH_9',
    'T_out','Press_mm_hg','RH_out','Windspeed','Visibility','Tdewpoint'
]
target = 'Appliances'

# Train/test split
train_df = df.iloc[:int(0.8 * len(df))]
test_df = df.iloc[int(0.8 * len(df)):].reset_index(drop=True)

# Train linear regression model
X_train, y_train = train_df[feature_cols], train_df[target]
model = LinearRegression().fit(X_train, y_train)

# Save feature names (for clean prediction)
feature_names = model.feature_names_in_

#  Live simulation pointer
current_index = 0

def get_next():
    global current_index
    if current_index >= len(test_df):
        current_index = 0
    row = test_df.iloc[current_index]
    current_index += 1
    return row

def detect_anomaly():
    row = get_next()
    actual = row["Appliances"]

    # Predict with DataFrame to preserve feature names
    features_df = pd.DataFrame([row[feature_cols].values], columns=feature_names)
    predicted = model.predict(features_df)[0]

    #Basic anomaly detection rule
    diff = abs(predicted - actual)
    anomaly = diff > (0.25 * predicted)  

    #Data structure sent to frontend
    data = {
        "timestamp": str(row["date"]),
        "predicted_usage": round(float(predicted), 2),
        "expected_avg": round(float(actual), 2),
        "anomaly": bool(anomaly),
        "context": {
            "T_out": round(float(row["T_out"]), 2),
            "RH_out": round(float(row["RH_out"]), 2),
        }
    }

    advice = generate_advice(data)
    return {**data, "advice": advice}
