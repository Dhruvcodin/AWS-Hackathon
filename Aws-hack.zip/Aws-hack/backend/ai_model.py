def generate_advice(data):
    """Generate a human-like summary of energy pattern."""
    anomaly = data["anomaly"]
    temp = data["context"]["T_out"]
    humidity = data["context"]["RH_out"]
    usage = data["predicted_usage"]
    avg = data["expected_avg"]

    diff = round(((usage - avg) / avg) * 100, 2) if avg else 0

    if anomaly and usage > avg:
        return (
            f" Energy usage is {abs(diff)}% higher than expected. "
            f"High temperature ({temp}°C) and humidity ({humidity}%) may be causing it."
        )
    elif anomaly and usage < avg:
        return (
            f" Energy usage is {abs(diff)}% lower than expected. "
            f"Possible appliance shutdown or reduced load detected."
        )
    else:
        return (
            f" Usage normal ({usage:.1f} Wh). "
            f"Conditions stable at {temp}°C and {humidity}% humidity."
        )
